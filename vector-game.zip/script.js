const canvas = document.getElementById("vectorCanvas");
const ctx = canvas.getContext("2d");
const input = document.getElementById("scalarInput");
const button = document.getElementById("drawBtn");

const baseVector = { x: 80, y: -60 };

function drawVector(x, y, color, label) {
  ctx.beginPath();
  ctx.moveTo(250, 200);
  ctx.lineTo(250 + x, 200 + y);
  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.fillStyle = color;
  ctx.font = "16px Vazir";
  ctx.fillText(label, 250 + x + 10, 200 + y + 10);
}

function draw() {
  const scalar = parseFloat(input.value);
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = "#bbb";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, 200);
  ctx.lineTo(500, 200);
  ctx.moveTo(250, 0);
  ctx.lineTo(250, 400);
  ctx.stroke();

  drawVector(baseVector.x, baseVector.y, "green", "A");
  drawVector(baseVector.x * scalar, baseVector.y * scalar, "blue", `${scalar}A`);
}

button.addEventListener("click", draw);
draw();